#ifdef openg
inline void readmmb(string s){
	char i;
	int j;
	m.clear();
	in.open((s+".mmb").c_str());
	for(j=0;j<62+ss.size();++j){
		getline(in,s);
		char a,b;
		a=s[0];
		b=s[2];
		m[a]=b;
		mc[b]=a;
	}
	in.close();
}
#endif
